package actor

class Package(val id: Int, val name: String)