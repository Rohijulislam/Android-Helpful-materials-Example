package com.raywenderlich.android.starsync.repository.model

data class BasePeople(val results: List<People>?)