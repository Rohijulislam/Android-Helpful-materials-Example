package com.raywenderlich.android.starsync.utils

enum class ProcessUsing {
  BackgroundThread, Coroutines
}