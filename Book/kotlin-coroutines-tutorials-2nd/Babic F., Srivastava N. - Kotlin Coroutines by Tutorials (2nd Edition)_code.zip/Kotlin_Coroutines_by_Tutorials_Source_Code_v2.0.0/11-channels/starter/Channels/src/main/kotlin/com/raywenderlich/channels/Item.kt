package com.raywenderlich.channels

interface Item {
  val name: String
  val color: String
}