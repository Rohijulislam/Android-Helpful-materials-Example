package com.raywenderlich.listmaker.ui.detail.ui.detail

import androidx.lifecycle.ViewModel

class ListDetailViewModel : ViewModel() {
  // TODO: Implement the ViewModel
}