package com.raywenderlich.listmaker.models

class TaskList(val name: String, val tasks: ArrayList<String> = ArrayList()) {
}